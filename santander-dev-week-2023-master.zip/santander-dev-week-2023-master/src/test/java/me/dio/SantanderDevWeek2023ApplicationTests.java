package me.dio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SantanderDevWeek2023ApplicationTests {

	@Test
	void contextLoads() {
	}

}
